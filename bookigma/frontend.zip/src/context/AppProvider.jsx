import { avatarSrc, DEFAULT_AVATAR } from '../lib/avatar';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { AppContext } from './contexts';
import * as seed from '../data/seed';
import { load, save, uid } from '../lib/storage';
import { DAILY_TASKS, FEED_XP, POINT_RULES, todayKey } from '../lib/gamification';
import { apiCall } from '../services/api';
import * as shopApi from '../services/shopApi';
import * as exchangeApi from '../services/exchangeApi';
import * as notificationApi from '../services/notificationApi';
import * as adminApi from '../services/adminApi';
import * as reportApi from '../services/reportApi';
import * as chatApi from '../lib/chatApi';
import * as friendApi from '../services/friendApi';
import { useAuth } from '../hooks/useStore';

/**
 * Dữ liệu riêng của người đang đăng nhập, lấy từ backend. Được "đánh khoá" theo userId:
 * khi đăng xuất / đổi tài khoản, dữ liệu cũ tự bị bỏ qua cho tới khi tải xong dữ liệu mới.
 */
const EMPTY_ACCOUNT = {
  userId: undefined,
  loaded: false,
  cart: [],
  orders: [],
  sellerBooks: [],
  sellerOrders: [],
  adminBooks: [],
  adminOrders: [],
  exchanges: [],
  myExchanges: [],
  sentOffers: [],
  notifications: [],
};

/** Gộp các danh sách theo id; phần tử đứng sau ghi đè phần tử trước nhưng giữ nguyên vị trí. */
function mergeById(...lists) {
  const map = new Map();
  lists.flat().forEach((item) => {
    if (item && item.id !== undefined) {
      map.set(item.id, item);
    }
  });
  return [...map.values()];
}

const replaceById = (list, item) =>
  list.some((x) => x.id === item.id) ? list.map((x) => (x.id === item.id ? item : x)) : [item, ...list];

/** Tải dữ liệu cửa hàng (sách, shop, thể loại, voucher).
 * Nếu backend chưa chạy, dùng dataset demo để giao diện vẫn hiển thị, thay vì hiện cảnh báo lỗi liên tục. */
async function fetchCatalog() {
  try {
    const [books, shops, categories, vouchers] = await Promise.all([
      shopApi.fetchBooks(),
      shopApi.fetchShops(),
      shopApi.fetchCategories(),
      shopApi.fetchVouchers(),
    ]);
    return { status: 'ready', books, shops, categories, vouchers };
  } catch {
    return {
      status: 'ready',
      books: seed.books,
      shops: seed.shops,
      categories: seed.CATEGORIES,
      vouchers: seed.vouchers,
    };
  }
}

const applyCatalog = (next) => (prev) => next || { ...prev, status: prev.books.length ? 'ready' : 'error' };

/**
 * Kho dữ liệu trung tâm.
 * - Shop, giỏ hàng, đơn hàng, Blind Book, trao đổi sách, thông báo: đọc/ghi qua API backend.
 * - Các phần chưa có backend (chat, tiến trình đọc, gamification, báo cáo...) vẫn lưu localStorage
 *   như bản demo, nên tải lại trang vẫn giữ nguyên trạng thái.
 */
export function AppProvider({ children }) {
  const { user, updateUserPoints, updateUserFields } = useAuth();
  const userId = user?.id ?? null;
  const role = user?.role ?? null;

  // Danh sách users luôn lấy từ backend/database; không khôi phục dữ liệu user ảo từ localStorage.
  const [users, setUsers] = useState([]);
  const [posts, setPosts] = useState([]);
  const [reports, setReports] = useState([]);
  const [conversations, setConversations] = useState([]);
  const [friendState, setFriendState] = useState({ friendIds: [], sentPendingIds: [], receivedPendingIds: [] });
  const [progressAll, setProgressAll] = useState(() => load('progress', seed.readingProgress));
  const [localNotifications, setLocalNotifications] = useState(() => load('notifications', seed.notifications));
  const [daily, setDaily] = useState(() => load('daily', {}));
  const [redemptions, setRedemptions] = useState(() => load('redemptions', seed.redemptions));
  // Không khôi phục social/followings demo từ localStorage.
  // Xóa riêng 2 key dữ liệu ảo cũ nếu chúng còn tồn tại; các localStorage khác giữ nguyên.
  const [social, setSocial] = useState({ friends: {}, followings: {} });

  useEffect(() => {
    try {
      localStorage.removeItem('users');
      localStorage.removeItem('social');
    } catch {}
  }, []);

  // Feed lấy dữ liệu thật từ MySQL; không dùng seed/localStorage cho bài viết.
  const normalizePost = useCallback((p) => ({
    id: p.id,
    authorId: p.userId,
    authorName: p.authorName || p.username,
    username: p.username,
    avatarUrl: p.avatarUrl || DEFAULT_AVATAR,
    content: p.content,
    image: p.imageUrl || null,
    bookId: p.bookId ?? null,
    time: p.createdAt ? new Date(p.createdAt).getTime() : Date.now(),
    likedBy: Array.isArray(p.likedBy) ? p.likedBy : [],
    likeCount: Number(p.likeCount || 0),
    likedByMe: Boolean(p.likedByMe),
    comments: Array.isArray(p.comments) ? p.comments.map((c) => ({
      id: c.id, authorId: c.userId, authorName: c.authorName || c.username, username: c.username,
      avatarUrl: c.avatarUrl || DEFAULT_AVATAR, text: c.content,
      time: c.createdAt ? new Date(c.createdAt).getTime() : Date.now(), parentCommentId: c.parentCommentId,
    })) : [],
    hidden: false,
  }), []);

  const refreshPosts = useCallback(async () => {
    const data = await apiCall('/posts', 'GET', null, { userId });
    if (Array.isArray(data)) setPosts(data.map(normalizePost));
  }, [userId, normalizePost]);

  useEffect(() => {
    let cancelled = false;
    if (!userId) { setPosts([]); return undefined; }
    refreshPosts().catch(() => {});
    const timer = setInterval(() => {
      if (!cancelled) refreshPosts().catch(() => {});
    }, 5000);
    return () => { cancelled = true; clearInterval(timer); };
  }, [userId, refreshPosts]);

  useEffect(() => save('progress', progressAll), [progressAll]);
  useEffect(() => save('notifications', localNotifications), [localNotifications]);
  useEffect(() => save('daily', daily), [daily]);
  useEffect(() => save('redemptions', redemptions), [redemptions]);

  // ---------- Cửa hàng (backend) ----------
  const [catalog, setCatalog] = useState({ status: 'loading', books: [], shops: [], categories: [], vouchers: [] });
  const [chaptersByBook, setChaptersByBook] = useState({});

  useEffect(() => {
    let cancelled = false;
    fetchCatalog().then((next) => {
      if (!cancelled) setCatalog(applyCatalog(next));
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const refreshCatalog = useCallback(async () => {
    setCatalog(applyCatalog(await fetchCatalog()));
  }, []);

  // ---------- Dữ liệu của người đang đăng nhập (backend) ----------
  const [accountState, setAccountState] = useState(EMPTY_ACCOUNT);
  const account = accountState.userId === userId ? accountState : EMPTY_ACCOUNT;

  /** Cập nhật một phần dữ liệu của người dùng forUser; bỏ qua nếu người dùng đã đổi. */
  const patchAccount = useCallback((forUser, patch) => {
    setAccountState((prev) =>
      prev.userId === forUser ? { ...prev, ...(typeof patch === 'function' ? patch(prev) : patch) } : prev
    );
  }, []);

  useEffect(() => {
    let cancelled = false;
    const settle = (result) => (result.status === 'fulfilled' ? result.value : []);
    (async () => {
      const results = await Promise.allSettled([
        exchangeApi.fetchListings(userId),
        userId ? shopApi.fetchCart(userId) : [],
        userId ? shopApi.fetchMyOrders(userId) : [],
        userId ? exchangeApi.fetchMyListings(userId) : [],
        userId ? exchangeApi.fetchSentOffers(userId) : [],
        userId ? notificationApi.fetchNotifications(userId) : [],
        (role === 'shop' || role === 'moderator') ? shopApi.fetchSellerBooks(userId) : [],
        (role === 'shop' || role === 'moderator') ? shopApi.fetchSellerOrders(userId) : [],
        role === 'admin' ? shopApi.fetchAdminBooks(userId) : [],
        role === 'admin' ? shopApi.fetchAdminOrders(userId) : [],
      ]);
      if (cancelled) return;
      const [
        exchanges,
        cart,
        orders,
        myExchanges,
        sentOffers,
        notifications,
        sellerBooks,
        sellerOrders,
        adminBooks,
        adminOrders,
      ] = results.map(settle);
      setAccountState({
        userId,
        loaded: true,
        exchanges,
        cart,
        orders,
        myExchanges,
        sentOffers,
        notifications,
        sellerBooks,
        sellerOrders,
        adminBooks,
        adminOrders,
      });
    })();
    return () => {
      cancelled = true;
    };
  }, [userId, role]);

  const refreshCart = useCallback(async () => {
    if (!userId) return;
    try {
      patchAccount(userId, { cart: await shopApi.fetchCart(userId) });
    } catch {}
  }, [userId, patchAccount]);

  const refreshOrders = useCallback(async () => {
    if (!userId) return;
    try {
      patchAccount(userId, { orders: await shopApi.fetchMyOrders(userId) });
    } catch {}
  }, [userId, patchAccount]);

  const refreshSellerData = useCallback(async () => {
    if (role !== 'shop' && role !== 'moderator') return;
    try {
      const [sellerBooks, sellerOrders] = await Promise.all([
        shopApi.fetchSellerBooks(userId),
        shopApi.fetchSellerOrders(userId),
      ]);
      patchAccount(userId, { sellerBooks, sellerOrders });
    } catch {}
  }, [userId, role, patchAccount]);

  const refreshAdminData = useCallback(async () => {
    if (role !== 'admin' || !userId) return;
    const results = await Promise.allSettled([
      shopApi.fetchAdminBooks(userId),
      shopApi.fetchAdminOrders(userId),
      adminApi.fetchPosts(userId),
      reportApi.fetchAdminReports(userId),
      adminApi.fetchUsers(userId),
    ]);
    const value = (i) => results[i].status === 'fulfilled' ? results[i].value : [];
    const adminPosts = value(2);
    const adminReports = value(3);
    const adminUsers = value(4);
    if (Array.isArray(adminUsers)) {
      setUsers(adminUsers.filter((u) => u && u.id != null).map((u) => ({
        ...u,
        id: String(u.id),
        name: u.fullName || u.username || 'Người dùng',
        avatar: avatarSrc(u.avatarUrl),
        role: String(u.role || 'USER').toLowerCase(),
        status: u.active === false ? 'suspended' : 'active',
        points: 0,
        booksRead: 0,
        joinedAt: u.createdAt,
      })));
    }
    if (Array.isArray(adminPosts)) setPosts(adminPosts.map(normalizePost));
    if (Array.isArray(adminReports)) setReports(adminReports.map((r) => ({
      id: r.id,
      reporterId: r.reporterId,
      reporterName: r.reporterName,
      type: String(r.targetType || '').toLowerCase(),
      targetId: r.targetId,
      targetLabel: r.targetLabel,
      targetContent: r.targetContent,
      reason: r.reason,
      detail: r.detail || '',
      status: String(r.status || 'PENDING').toLowerCase() === 'dismissed' ? 'rejected' : String(r.status || 'PENDING').toLowerCase(),
      handledBy: r.resolvedBy,
      handledByName: r.resolvedByName,
      handledNote: r.detail || '',
      createdAt: r.createdAt ? new Date(r.createdAt).getTime() : Date.now(),
    })));
    patchAccount(userId, { adminBooks: value(0), adminOrders: value(1) });
  }, [userId, role, patchAccount, normalizePost]);

  const refreshExchanges = useCallback(async () => {
    try {
      const [exchanges, myExchanges, sentOffers] = await Promise.all([
        exchangeApi.fetchListings(userId),
        userId ? exchangeApi.fetchMyListings(userId) : [],
        userId ? exchangeApi.fetchSentOffers(userId) : [],
      ]);
      patchAccount(userId, { exchanges, myExchanges, sentOffers });
    } catch {}
  }, [userId, patchAccount]);

  const refreshNotifications = useCallback(async () => {
    if (!userId) return;
    try {
      patchAccount(userId, { notifications: await notificationApi.fetchNotifications(userId) });
    } catch {}
  }, [userId, patchAccount]);

  useEffect(() => {
    if (!userId) return undefined;
    const timer = setInterval(refreshNotifications, 30000);
    return () => clearInterval(timer);
  }, [userId, refreshNotifications]);

  // ---------- Tra cứu ----------
  const books = useMemo(
    () =>
      mergeById(catalog.books, account.sellerBooks, account.adminBooks).map((book) =>
        chaptersByBook[book.id] ? { ...book, chapters: chaptersByBook[book.id] } : book
      ),
    [catalog.books, account.sellerBooks, account.adminBooks, chaptersByBook]
  );

  const exchanges = useMemo(
    () => mergeById(account.exchanges, account.myExchanges),
    [account.exchanges, account.myExchanges]
  );

  const knownUsers = useMemo(() => {
    const map = new Map();
    const put = (entry) => {
      if (entry?.id === null || entry?.id === undefined || map.has(entry.id)) return;
      map.set(entry.id, { role: 'user', status: 'active', badge: 'Thành viên', points: 0, booksRead: 0, ...entry });
    };
    if (user) put({ id: user.id, name: user.name, avatar: user.avatar, role: user.role, email: user.email });
    (catalog.shops || []).forEach((shop) =>
      put({ id: shop.ownerId, name: shop.name, avatar: shop.avatar, role: 'shop', badge: 'Đối tác' })
    );
    (exchanges || []).forEach((listing) => put(listing.owner));
    (account.myExchanges || []).forEach((listing) => listing.offers?.forEach((offer) => put(offer.sender)));
    (account.sentOffers || []).forEach((offer) => put(offer.owner));
    return map;
  }, [user, catalog.shops, exchanges, account.myExchanges, account.sentOffers]);

  const userById = useCallback(
    (id) => users.find((u) => String(u.id) === String(id)) || knownUsers.get(id),
    [users, knownUsers]
  );

  const bookById = useCallback((id) => books.find((b) => String(b.id) === String(id)), [books]);
  const shopById = useCallback(
    (id) => (catalog.shops || seed.shops || []).find((s) => String(s.id) === String(id)),
    [catalog.shops]
  );

  const upsertUser = useCallback((userData) => {
    if (!userData || !userData.id) return null;
    const nextUser = {
      ...userData,
      id: String(userData.id),
      name: userData.name || userData.fullName || userData.username || 'Người dùng',
      avatar: avatarSrc(userData.avatar || userData.avatarUrl),
      role: userData.role || 'user',
      status: userData.status || 'active',
      badge: userData.badge || 'Thành viên',
      points: userData.points || 0,
      booksRead: userData.booksRead || 0,
      joinedAt: userData.joinedAt || new Date().toISOString().slice(0, 10),
    };
    setUsers((prev) => {
      const exists = prev.some((u) => String(u.id) === String(nextUser.id));
      if (exists) {
        return prev.map((u) => (String(u.id) === String(nextUser.id) ? { ...u, ...nextUser } : u));
      }
      return [nextUser, ...prev];
    });
    return nextUser;
  }, []);

  const syncUsers = useCallback(async () => {
    try {
      const data = role === 'admin' && userId
        ? await adminApi.fetchUsers(userId)
        : await apiCall('/users');
      if (!Array.isArray(data)) return [];
      const normalized = data
        .filter((u) => u && Number.isFinite(Number(u.id)))
        .map((u) => ({
          ...u,
          id: String(u.id),
          name: u.fullName || u.username || 'Người dùng',
          avatar: avatarSrc(u.avatarUrl),
          role: (u.role || 'user').toLowerCase(),
          status: u.active === false ? 'suspended' : 'active',
          badge: 'Thành viên',
          points: 0,
          booksRead: 0,
          joinedAt: u.createdAt || new Date().toISOString(),
        }));

      setUsers((prev) => {
        const existing = new Map(prev.map((u) => [String(u.id), u]));
        normalized.forEach((u) => existing.set(String(u.id), { ...existing.get(String(u.id)), ...u }));
        return Array.from(existing.values());
      });
      return normalized;
    } catch {
      return [];
    }
  }, [role, userId]);

  useEffect(() => {
    syncUsers();
  }, [syncUsers]);

  // ---------- Mạng xã hội / Bạn bè ----------
  const getFriends = useCallback((uId) => {
    if (!uId || String(uId) !== String(userId)) return [];
    return friendState.friendIds || [];
  }, [friendState.friendIds, userId]);

  const getFollowing = useCallback((uId) => social.followings?.[uId] || [], [social]);

  const getFollowers = useCallback(
    (uId) => Object.entries(social.followings || {}).filter(([, ids]) => ids.includes(uId)).map(([id]) => id),
    [social]
  );

  const isFriend = useCallback(
    (uId, otherId) => String(uId) !== String(otherId) && getFriends(uId).some((id) => String(id) === String(otherId)),
    [getFriends]
  );

  const isFollowing = useCallback(
    (uId, otherId) => !!uId && !!otherId && String(uId) !== String(otherId) && getFollowing(uId).some((id) => String(id) === String(otherId)),
    [getFollowing]
  );

  const hasSentFriendRequest = useCallback(
    (uId, otherId) => String(uId) === String(userId) && (friendState.sentPendingIds || []).some((id) => String(id) === String(otherId)),
    [friendState.sentPendingIds, userId]
  );

  const hasReceivedFriendRequest = useCallback(
    (uId, otherId) => String(uId) === String(userId) && (friendState.receivedPendingIds || []).some((id) => String(id) === String(otherId)),
    [friendState.receivedPendingIds, userId]
  );

  const refreshFriendState = useCallback(async () => {
    if (!userId) return;
    const state = await friendApi.getFriendState(userId);
    setFriendState({
      friendIds: (state?.friendIds || []).map(String),
      sentPendingIds: (state?.sentPendingIds || []).map(String),
      receivedPendingIds: (state?.receivedPendingIds || []).map(String),
    });

    // Đồng bộ username/fullName/avatar thật từ database vào danh sách users.
    const remoteUsers = [
      ...(state?.friends || []),
      ...(state?.sentPendingUsers || []),
      ...(state?.receivedPendingUsers || []),
    ];
    if (remoteUsers.length) {
      setUsers((prev) => {
        const map = new Map(prev.map((u) => [String(u.id), u]));
        remoteUsers.forEach((u) => {
          const existing = map.get(String(u.id)) || {};
          map.set(String(u.id), {
            ...existing,
            id: Number(u.id),
            username: u.username,
            fullName: u.fullName,
            name: u.fullName || u.username || existing.name || 'Người dùng',
            avatarUrl: u.avatarUrl || existing.avatarUrl || null,
            avatar: avatarSrc(u.avatarUrl || existing.avatar),
            bio: u.bio || '',
            role: String(u.role || existing.role || 'USER').toLowerCase(),
          });
        });
        return Array.from(map.values());
      });
    }
  }, [userId]);

  useEffect(() => {
    if (!userId) {
      setFriendState({ friendIds: [], sentPendingIds: [], receivedPendingIds: [] });
      return undefined;
    }
    refreshFriendState().catch(() => {});
    return undefined;
  }, [userId, refreshFriendState]);

  const toggleFriend = useCallback(async (uId, otherId) => {
    if (!uId || !otherId || String(uId) === String(otherId)) return false;
    try {
      if (isFriend(uId, otherId) || hasSentFriendRequest(uId, otherId)) {
        await friendApi.cancelFriendRequest(uId, otherId);
      } else {
        await friendApi.sendFriendRequest(uId, otherId);
      }
      await refreshFriendState();
      return true;
    } catch {
      return false;
    }
  }, [isFriend, hasSentFriendRequest, refreshFriendState]);

  const acceptFriendRequest = useCallback(async (uId, otherId) => {
    try {
      await friendApi.acceptFriendRequest(uId, otherId);
      await refreshFriendState();
      return true;
    } catch {
      return false;
    }
  }, [refreshFriendState]);

  const rejectFriendRequest = useCallback(async (uId, otherId) => {
    try {
      await friendApi.rejectFriendRequest(uId, otherId);
      await refreshFriendState();
      return true;
    } catch {
      return false;
    }
  }, [refreshFriendState]);

  const toggleFollow = useCallback((uId, otherId) => {
    if (!uId || !otherId || uId === otherId) return false;
    let nextValue = false;
    setSocial((prev) => {
      const nextFollowing = { ...(prev.followings || {}) };
      const mine = new Set(nextFollowing[uId] || []);
      if (mine.has(otherId)) { mine.delete(otherId); nextValue = false; }
      else { mine.add(otherId); nextValue = true; }
      nextFollowing[uId] = Array.from(mine);
      return { ...prev, followings: nextFollowing };
    });
    return nextValue;
  }, []);

  const loadBook = useCallback(
    async (id) => {
      const book = await shopApi.fetchBook(id, userId);
      setChaptersByBook((prev) => ({ ...prev, [book.id]: book.chapters || [] }));
      return book;
    },
    [userId]
  );

  // ---------- Giỏ hàng ----------
  const persistFallbackCart = useCallback((forUser, cart) => {
    if (!forUser) return cart;
    const nextCart = Array.isArray(cart) ? cart : [];
    save(`cart.${forUser}`, nextCart);
    return nextCart;
  }, []);

  const readFallbackCart = useCallback((forUser) => {
    if (!forUser) return [];
    const saved = load(`cart.${forUser}`, []);
    return Array.isArray(saved) ? saved : [];
  }, []);

  const getCart = useCallback((forUser) => {
    if (forUser !== userId) return [];
    const current = Array.isArray(account.cart) ? account.cart : [];
    return current.length > 0 ? current : readFallbackCart(forUser);
  }, [userId, account.cart, readFallbackCart]);

  const addToCart = useCallback(
    async (forUser, bookId, qty = 1) => {
      try {
        const cart = await shopApi.addCartItem(forUser, { bookId: Number(bookId), quantity: qty });
        patchAccount(forUser, { cart });
        persistFallbackCart(forUser, cart);
        return cart;
      } catch {
        const existing = Array.isArray(account.cart) ? account.cart : readFallbackCart(forUser);
        const targetBook = books.find((b) => String(b.id) === String(bookId));
        const nextLine = {
          id: `local-${forUser}-${bookId}-${Date.now()}`,
          qty,
          available: true,
          unavailableReason: null,
          bookId: Number(bookId),
          blind: null,
          book: targetBook ? {
            id: targetBook.id,
            title: targetBook.title,
            author: targetBook.author,
            cover: targetBook.cover,
            price: targetBook.price,
            stock: targetBook.stock,
            shopId: targetBook.shopId,
            shopName: targetBook.shopName,
          } : {
            id: Number(bookId),
            title: 'Sách',
            author: 'Đang cập nhật',
            cover: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&q=80',
            price: 0,
            stock: 99,
            shopId: null,
            shopName: 'Bookigma',
          },
        };

        const nextCart = [...existing];
        const idx = nextCart.findIndex((line) => line.bookId === Number(bookId) && !line.blind);
        if (idx >= 0) {
          nextCart[idx] = { ...nextCart[idx], qty: nextCart[idx].qty + qty };
        } else {
          nextCart.push(nextLine);
        }

        patchAccount(forUser, { cart: nextCart });
        persistFallbackCart(forUser, nextCart);
        return nextCart;
      }
    },
    [account.cart, books, patchAccount, persistFallbackCart, readFallbackCart]
  );

  const updateCartQty = useCallback(
    async (itemId, qty) => {
      try {
        const cart = await shopApi.updateCartItem(userId, itemId, qty);
        patchAccount(userId, { cart });
        persistFallbackCart(userId, cart);
      } catch {
        const current = getCart(userId);
        const nextCart = current.map((line) => (line.id === itemId ? { ...line, qty: Math.max(1, qty) } : line));
        patchAccount(userId, { cart: nextCart });
        persistFallbackCart(userId, nextCart);
      }
    },
    [userId, patchAccount, persistFallbackCart, getCart]
  );

  const removeCartItem = useCallback(
    async (itemId) => {
      try {
        const cart = await shopApi.removeCartItem(userId, itemId);
        patchAccount(userId, { cart });
        persistFallbackCart(userId, cart);
      } catch {
        const current = getCart(userId);
        const nextCart = current.filter((line) => line.id !== itemId);
        patchAccount(userId, { cart: nextCart });
        persistFallbackCart(userId, nextCart);
      }
    },
    [userId, patchAccount, persistFallbackCart, getCart]
  );

  const setCartQty = useCallback((forUser, bookId, qty) => {
    // Tương thích với các gọi hàm cũ
  }, []);

  const removeFromCart = useCallback((forUser, bookId) => {}, []);
  const clearCart = useCallback((forUser) => {}, []);

  // ---------- Đơn hàng (người mua) ----------
  const replaceOrder = useCallback(
    (order) => {
      patchAccount(userId, (prev) => ({ orders: replaceById(prev.orders, order) }));
    },
    [userId, patchAccount]
  );

  const placeOrder = useCallback(
    async (checkout) => {
      const created = await shopApi.checkout(userId, checkout);
      patchAccount(userId, (prev) => ({ orders: [...created, ...prev.orders], cart: [] }));
      refreshCatalog();
      refreshNotifications();
      return created;
    },
    [userId, patchAccount, refreshCatalog, refreshNotifications]
  );

  const cancelOrder = useCallback(
    async (orderId, reason) => {
      const order = await shopApi.cancelOrder(userId, orderId, reason);
      replaceOrder(order);
      refreshCatalog();
      return order;
    },
    [userId, replaceOrder, refreshCatalog]
  );

  const completeOrder = useCallback(
    async (orderId) => {
      const order = await shopApi.completeOrder(userId, orderId);
      replaceOrder(order);
      return order;
    },
    [userId, replaceOrder]
  );

  const updateOrderStatus = useCallback((orderId, status, note) => {}, []);

  // ---------- Kênh người bán ----------
  const saveSellerBook = useCallback(
    async (bookId, form) => {
      const book = bookId
        ? await shopApi.updateSellerBook(userId, bookId, form)
        : await shopApi.createSellerBook(userId, form);
      patchAccount(userId, (prev) => ({ sellerBooks: replaceById(prev.sellerBooks, book) }));
      refreshCatalog();
      return book;
    },
    [userId, patchAccount, refreshCatalog]
  );

  const upsertBook = useCallback(
    (book) => {
      saveSellerBook(book.id, book);
    },
    [saveSellerBook]
  );

  const deleteSellerBook = useCallback(
    async (bookId) => {
      const result = await shopApi.deleteSellerBook(userId, bookId);
      patchAccount(userId, (prev) => ({
        sellerBooks: result.deleted
          ? prev.sellerBooks.filter((b) => b.id !== bookId)
          : prev.sellerBooks.map((b) => (b.id === bookId ? { ...b, status: 'hidden' } : b)),
      }));
      refreshCatalog();
      return result;
    },
    [userId, patchAccount, refreshCatalog]
  );

  const updateSellerOrderStatus = useCallback(
    async (orderId, status, note) => {
      const order = await shopApi.updateSellerOrderStatus(userId, orderId, status, note);
      patchAccount(userId, (prev) => ({ sellerOrders: replaceById(prev.sellerOrders, order) }));
      return order;
    },
    [userId, patchAccount]
  );

  // ---------- Quản trị sản phẩm ----------
  const setBookStatus = useCallback(
    async (bookId, status) => {
      const book = await shopApi.updateBookStatus(userId, bookId, status);
      patchAccount(userId, (prev) => ({ adminBooks: replaceById(prev.adminBooks, book) }));
      refreshCatalog();
      return book;
    },
    [userId, patchAccount, refreshCatalog]
  );

  const deleteBook = useCallback(
    async (bookId) => {
      const result = await shopApi.deleteBookAsAdmin(userId, bookId);
      patchAccount(userId, (prev) => ({
        adminBooks: result.deleted
          ? prev.adminBooks.filter((b) => b.id !== bookId)
          : prev.adminBooks.map((b) => (b.id === bookId ? { ...b, status: 'hidden' } : b)),
      }));
      refreshCatalog();
      return result;
    },
    [userId, patchAccount, refreshCatalog]
  );

  // ---------- Bài đăng (MySQL) ----------
  const addPost = useCallback(async (post) => {
    if (!userId) throw new Error('Bạn cần đăng nhập để đăng bài.');
    const saved = await apiCall('/posts', 'POST', {
      content: post.content,
      imageUrl: post.image || null,
      bookId: /^\d+$/.test(String(post.bookId || '')) ? Number(post.bookId) : null,
      visibility: 'PUBLIC',
    }, { userId });
    const normalized = normalizePost(saved);
    setPosts((prev) => [normalized, ...prev.filter((p) => p.id !== normalized.id)]);
    return normalized;
  }, [userId, normalizePost]);

  const toggleLike = useCallback(async (postId) => {
    if (!userId) throw new Error('Bạn cần đăng nhập để thích bài viết.');
    const saved = await apiCall(`/posts/${postId}/like`, 'POST', null, { userId });
    const normalized = normalizePost(saved);
    setPosts((prev) => prev.map((p) => p.id === normalized.id ? normalized : p));
    return normalized;
  }, [userId, normalizePost]);

  const addComment = useCallback(async (postId, comment) => {
    if (!userId) throw new Error('Bạn cần đăng nhập để bình luận.');
    const savedComment = await apiCall(`/posts/${postId}/comments`, 'POST', {
      content: comment.text,
      parentCommentId: comment.parentCommentId || null,
    }, { userId });
    const normalizedComment = {
      id: savedComment.id, authorId: savedComment.userId, authorName: savedComment.authorName || savedComment.username,
      username: savedComment.username, avatarUrl: savedComment.avatarUrl, text: savedComment.content,
      time: savedComment.createdAt ? new Date(savedComment.createdAt).getTime() : Date.now(),
      parentCommentId: savedComment.parentCommentId,
    };
    setPosts((prev) => prev.map((p) => p.id === postId ? { ...p, comments: [...p.comments, normalizedComment] } : p));
    return normalizedComment;
  }, [userId]);

  const setPostHidden = useCallback((postId, hidden) => {
    setPosts((prev) => prev.map((p) => (p.id === postId ? { ...p, hidden } : p)));
  }, []);

  const deletePost = useCallback(async (postId) => {
    if (!userId) throw new Error('Bạn cần đăng nhập.');
    const result = await adminApi.deletePost(userId, postId);
    setPosts((prev) => prev.filter((p) => p.id !== postId));
    return result;
  }, [userId]);

  // ---------- Báo cáo vi phạm (backend/MySQL) ----------
  const addReport = useCallback(async (report) => {
    if (!userId) throw new Error('Bạn cần đăng nhập.');
    const saved = await reportApi.createReport(userId, {
      targetType: String(report.type || '').toUpperCase(),
      targetId: report.targetId,
      reason: report.reason,
      detail: report.detail || null,
    });
    const normalized = {
      id: saved.id,
      reporterId: saved.reporterId,
      reporterName: saved.reporterName,
      type: String(saved.targetType || '').toLowerCase(),
      targetId: saved.targetId,
      targetLabel: saved.targetLabel,
      targetContent: saved.targetContent,
      reason: saved.reason,
      detail: saved.detail || '',
      status: String(saved.status || 'PENDING').toLowerCase(),
      handledBy: saved.resolvedBy,
      handledByName: saved.resolvedByName,
      handledNote: '',
      createdAt: saved.createdAt ? new Date(saved.createdAt).getTime() : Date.now(),
    };
    setReports((prev) => [normalized, ...prev]);
    return normalized;
  }, [userId]);

  const resolveReport = useCallback(async (reportId, status, handledBy, handledNote, action = 'NONE') => {
    if (!userId) throw new Error('Bạn cần đăng nhập.');
    const saved = await reportApi.resolveAdminReport(userId, reportId, {
      status: status === 'resolved' ? 'RESOLVED' : 'DISMISSED',
      action,
      note: handledNote || null,
    });
    const normalized = {
      id: saved.id,
      reporterId: saved.reporterId,
      reporterName: saved.reporterName,
      type: String(saved.targetType || '').toLowerCase(),
      targetId: saved.targetId,
      targetLabel: saved.targetLabel,
      targetContent: saved.targetContent,
      reason: saved.reason,
      detail: saved.detail || '',
      status: String(saved.status || 'PENDING').toLowerCase() === 'dismissed' ? 'rejected' : String(saved.status || 'PENDING').toLowerCase(),
      handledBy: saved.resolvedBy,
      handledByName: saved.resolvedByName,
      handledNote: handledNote || '',
      createdAt: saved.createdAt ? new Date(saved.createdAt).getTime() : Date.now(),
    };
    setReports((prev) => prev.map((r) => String(r.id) === String(reportId) ? normalized : r));
    if (action !== 'NONE') await refreshPosts();
    return normalized;
  }, [userId, refreshPosts]);

  // ---------- Người dùng (admin) ----------
  const setUserStatus = useCallback(async (uId, status) => {
    if (!userId) throw new Error('Bạn cần đăng nhập.');
    const active = status !== 'suspended';
    const saved = await adminApi.updateUserStatus(userId, uId, active);
    upsertUser({
      id: saved.id,
      username: saved.username,
      email: saved.email,
      fullName: saved.fullName,
      avatarUrl: saved.avatarUrl,
      role: String(saved.role || 'USER').toLowerCase(),
      active: saved.active,
    });
    return saved;
  }, [userId, upsertUser]);

  const updateUserRole = useCallback(async (uId, role) => {
    if (!userId) throw new Error('Bạn cần đăng nhập.');
    const saved = await adminApi.updateUserRole(userId, uId, role);
    upsertUser({
      id: saved.id,
      username: saved.username,
      email: saved.email,
      fullName: saved.fullName,
      avatarUrl: saved.avatarUrl,
      role: String(saved.role || 'USER').toLowerCase(),
      active: saved.active,
    });
    return saved;
  }, [userId, upsertUser]);

  const deleteUser = useCallback(async (uId) => {
    if (!userId) throw new Error('Bạn cần đăng nhập.');
    const result = await adminApi.deleteUser(userId, uId);
    setUsers((prev) => prev.filter((u) => String(u.id) !== String(uId)));
    return result;
  }, [userId]);

  const registerUser = useCallback((data) => {
    const newUser = {
      id: uid('u'),
      role: 'user',
      status: 'active',
      points: 0,
      badge: 'Thành viên mới',
      booksRead: 0,
      bio: '',
      avatar: DEFAULT_AVATAR,
      joinedAt: new Date().toISOString().slice(0, 10),
      ...data,
    };
    setUsers((prev) => [...prev, newUser]);
    return newUser;
  }, []);

  // ---------- Trao đổi sách ----------
  const addExchange = useCallback(
    async (form) => {
      const listing = await exchangeApi.createListing(userId, form);
      await refreshExchanges();
      return listing;
    },
    [userId, refreshExchanges]
  );

  const sendExchangeOffer = useCallback(
    async (listingId, form) => {
      const offer = await exchangeApi.sendOffer(userId, listingId, form);
      await refreshExchanges();
      return offer;
    },
    [userId, refreshExchanges]
  );

  const respondExchangeOffer = useCallback(
    async (offerId, action) => {
      const offer = await exchangeApi.respondToOffer(userId, offerId, action);
      await refreshExchanges();
      return offer;
    },
    [userId, refreshExchanges]
  );

  const setExchangeStatus = useCallback(
    async (listingId, status) => {
      const listing = await exchangeApi.updateListingStatus(userId, listingId, status);
      await refreshExchanges();
      return listing;
    },
    [userId, refreshExchanges]
  );

  const deleteExchange = useCallback(
    async (listingId) => {
      await exchangeApi.deleteListing(userId, listingId);
      await refreshExchanges();
    },
    [userId, refreshExchanges]
  );

  // ---------- Chat ----------
  const mapConversation = useCallback((c, previous = null) => ({
    id: String(c.id),
    name: c.name,
    type: c.type,
    participants: (c.participantIds || []).map(String),
    messages: (c.messages || []).map((m) => ({
      id: String(m.id),
      senderId: String(m.senderId),
      text: m.content,
      at: new Date(m.createdAt).getTime(),
    })),
    updatedAt: new Date(c.updatedAt).getTime(),
    readBy: previous?.readBy || {},
  }), []);

  const refreshConversations = useCallback(async () => {
    if (!userId) return [];
    const data = await chatApi.listChatConversations(userId);
    setConversations((prev) => {
      const old = new Map(prev.map((c) => [String(c.id), c]));
      return (Array.isArray(data) ? data : []).map((c) => mapConversation(c, old.get(String(c.id))));
    });
    return data;
  }, [userId, mapConversation]);

  useEffect(() => {
    if (!userId) {
      setConversations([]);
      return undefined;
    }
    refreshConversations().catch(() => {});
    const timer = setInterval(() => refreshConversations().catch(() => {}), 2500);
    return () => clearInterval(timer);
  }, [userId, refreshConversations]);

  const findOrCreateConversation = useCallback(async (userA, userB) => {
    const existing = conversations.find((c) =>
      c.type === 'DIRECT' &&
      c.participants.some((p) => String(p) === String(userA)) &&
      c.participants.some((p) => String(p) === String(userB))
    );
    if (existing) return existing.id;

    const created = await chatApi.createDirectConversation(userA, userB);
    const mapped = mapConversation(created);
    setConversations((prev) => [mapped, ...prev.filter((c) => String(c.id) !== String(mapped.id))]);
    return mapped.id;
  }, [conversations, mapConversation]);

  const createGroupConversation = useCallback(async (creatorId, participantIds, name) => {
    const created = await chatApi.createGroupConversation({
      creatorId,
      participantIds: participantIds.map(Number),
      name,
    });
    const mapped = mapConversation(created);
    setConversations((prev) => [mapped, ...prev]);
    return mapped;
  }, [mapConversation]);

  const sendMessage = useCallback(async (convId, senderId, text) => {
    const saved = await chatApi.sendChatMessage(convId, senderId, text);
    const message = {
      id: String(saved.id),
      senderId: String(saved.senderId),
      text: saved.content,
      at: new Date(saved.createdAt).getTime(),
    };
    setConversations((prev) => prev.map((c) => c.id === String(convId)
      ? { ...c, messages: [...c.messages, message], updatedAt: message.at, readBy: { ...c.readBy, [String(senderId)]: c.messages.length + 1 } }
      : c));
    return message;
  }, []);

  const markConversationRead = useCallback((convId, uId) => {
    setConversations((prev) => prev.map((c) =>
      c.id === String(convId)
        ? { ...c, readBy: { ...c.readBy, [String(uId)]: c.messages.length } }
        : c
    ));
  }, []);

  const unreadCount = useCallback(
    (uId) => conversations
      .filter((c) => c.participants.includes(String(uId)) || c.participants.includes(uId))
      .reduce((sum, c) => sum + Math.max(0, c.messages.length - (c.readBy?.[String(uId)] ?? 0)), 0),
    [conversations]
  );

  // ---------- Tiến trình đọc ----------
  const getProgress = useCallback((uId) => progressAll[uId] || {}, [progressAll]);

  const saveProgress = useCallback((uId, bookId, patch) => {
    setProgressAll((prev) => {
      const forUser = prev[uId] || {};
      const current = forUser[bookId] || {
        bookId,
        chapterIndex: 0,
        paragraphIndex: 0,
        percent: 0,
        secondsRead: 0,
        finished: false,
      };
      const unchanged = Object.keys(patch).every((k) => current[k] === patch[k]);
      if (unchanged) return prev;

      const next = { ...current, ...patch, lastReadAt: Date.now() };
      next.finished = next.percent >= 100;
      return { ...prev, [uId]: { ...forUser, [bookId]: next } };
    });
  }, []);

  // ---------- Gamification ----------
  const getDaily = useCallback(
    (uId) => {
      const d = daily[uId];
      return d && d.date === todayKey() ? d : { date: todayKey(), counters: {}, claimed: [] };
    },
    [daily]
  );

  const earnPoints = useCallback(
    (uId, amount) => {
      if (!uId || !amount) return;
      setUsers((prev) => prev.map((u) => (u.id === uId ? { ...u, points: (u.points || 0) + amount } : u)));
      if (user && String(user.id) === String(uId) && updateUserFields) {
        updateUserFields({ points: (user.points || 0) + amount });
      }
    },
    [user, updateUserFields]
  );

  const trackDaily = useCallback((uId, metric, amount = 1) => {
    if (!uId) return;
    setDaily((prev) => {
      const today = todayKey();
      const cur = prev[uId]?.date === today ? prev[uId] : { date: today, counters: {}, claimed: [] };
      const goal = Math.max(...DAILY_TASKS.filter((t) => t.metric === metric).map((t) => t.goal), 0);
      const now = cur.counters[metric] || 0;
      if (goal && now >= goal) return prev;
      return { ...prev, [uId]: { ...cur, counters: { ...cur.counters, [metric]: now + amount } } };
    });
  }, []);

  const claimTask = useCallback((uId, taskId) => {
    const task = DAILY_TASKS.find((t) => t.id === taskId);
    if (!task) return 0;
    let granted = 0;
    setDaily((prev) => {
      const today = todayKey();
      const cur = prev[uId]?.date === today ? prev[uId] : { date: today, counters: {}, claimed: [] };
      if (cur.claimed.includes(taskId)) return prev;
      if ((cur.counters[task.metric] || 0) < task.goal) return prev;
      granted = task.reward;
      return { ...prev, [uId]: { ...cur, claimed: [...cur.claimed, taskId] } };
    });
    return granted;
  }, []);

  const touchStreak = useCallback((uId) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== uId) return u;
        const today = todayKey();
        if (u.lastStreakDate === today) return u;
        const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
        const streak = u.lastStreakDate === yesterday ? (u.streak || 0) + 1 : 1;
        return { ...u, streak, lastStreakDate: today, points: (u.points || 0) + POINT_RULES.dailyStreak };
      })
    );
  }, []);

  const feedPet = useCallback(
    (uId, cost) => {
      const now = Date.now();
      const newXp = (user?.petXp || 0) + FEED_XP;
      setUsers((prev) =>
        prev.map((u) =>
          u.id === uId
            ? { ...u, points: Math.max(0, (u.points || 0) - cost), petXp: (u.petXp || 0) + FEED_XP, petLastFed: now }
            : u
        )
      );
      if (user && String(user.id) === String(uId) && updateUserFields) {
        updateUserFields({
          points: Math.max(0, (user.points || 0) - cost),
          petXp: newXp,
          petLastFed: now,
        });
      }
    },
    [user, updateUserFields]
  );

  const growPet = useCallback((uId, xp) => {
    setUsers((prev) => prev.map((u) => (u.id === uId ? { ...u, petXp: (u.petXp || 0) + xp } : u)));
    if (user && String(user.id) === String(uId) && updateUserFields) {
      updateUserFields({ petXp: (user.petXp || 0) + xp });
    }
  }, [user, updateUserFields]);

  const renamePet = useCallback((uId, name) => {
    setUsers((prev) => prev.map((u) => (u.id === uId ? { ...u, petName: name } : u)));
    if (user && String(user.id) === String(uId) && updateUserFields) {
      updateUserFields({ petName: name });
    }
  }, [user, updateUserFields]);

  const redeemReward = useCallback(
    (uId, reward, currentBalance) => {
      let ok = false;
      const effectivePoints = currentBalance ?? user?.points ?? 0;
      if (effectivePoints < reward.cost) return false;
      ok = true;
      const now = Date.now();
      const isPetReward = reward.type === 'pet';
      const newPetXp = isPetReward ? (user?.petXp || 0) + FEED_XP : (user?.petXp || 0);

      setUsers((prev) =>
        prev.map((u) => {
          if (u.id !== uId) return u;
          return {
            ...u,
            points: Math.max(0, effectivePoints - reward.cost),
            ...(isPetReward ? { petXp: (u.petXp || 0) + FEED_XP, petLastFed: now } : {}),
          };
        })
      );
      if (user && String(user.id) === String(uId) && updateUserFields) {
        updateUserFields({
          points: Math.max(0, effectivePoints - reward.cost),
          ...(isPetReward ? { petXp: newPetXp, petLastFed: now } : {}),
        });
      }
      if (ok) {
        setRedemptions((prev) => [
          { id: uid('rd'), userId: uId, rewardId: reward.id, name: reward.name, cost: reward.cost, at: Date.now() },
          ...prev,
        ]);
      }
      return ok;
    },
    [user, updateUserFields]
  );

  // ---------- Blind Book ----------
  const matchBlindBox = useCallback((payload) => shopApi.matchBlindBox(userId, payload), [userId]);

  const addBlindBox = useCallback(
    async (boxIdOrUser, bookId, blind) => {
      if (typeof boxIdOrUser === 'string' && bookId) {
        // Hỗ trợ hàm legacy
        return;
      }
      patchAccount(userId, { cart: await shopApi.addCartItem(userId, { blindBoxId: boxIdOrUser }) });
    },
    [userId, patchAccount]
  );

  const revealBlindBox = useCallback(
    async (orderId, itemId) => {
      const order = await shopApi.revealBlindBox(userId, orderId, itemId);
      replaceOrder(order);
      return order;
    },
    [userId, replaceOrder]
  );

  // ---------- Thông báo ----------
  const notifications = useMemo(
    () => [...(account.notifications || []), ...localNotifications].sort((a, b) => b.at - a.at),
    [account.notifications, localNotifications]
  );

  const pushNotification = useCallback((uId, text, link = '/') => {
    setLocalNotifications((prev) => [{ id: uid('n'), userId: uId, text, at: Date.now(), read: false, link }, ...prev]);
  }, []);

  const markNotificationsRead = useCallback(
    (forUser) => {
      setLocalNotifications((prev) => prev.map((n) => (n.userId === forUser ? { ...n, read: true } : n)));
      if (forUser && forUser === userId && account.notifications.some((n) => !n.read)) {
        patchAccount(forUser, (prev) => ({ notifications: prev.notifications.map((n) => ({ ...n, read: true })) }));
        notificationApi.markAllNotificationsRead(forUser).catch(() => {});
      }
    },
    [userId, account.notifications, patchAccount]
  );

  const value = useMemo(
    () => ({
      users,
      books,
      posts,
      refreshPosts,
      exchanges,
      orders: account.orders,
      reports,
      conversations,
      notifications,
      shops: catalog.shops || seed.shops,
      categories: catalog.categories || seed.CATEGORIES,
      vouchers: catalog.vouchers || seed.vouchers,
      catalogStatus: catalog.status,
      accountReady: account.loaded,
      sellerBooks: account.sellerBooks,
      sellerOrders: account.sellerOrders,
      adminOrders: account.adminOrders,
      myExchanges: account.myExchanges,
      sentOffers: account.sentOffers,
      userById,
      bookById,
      shopById,
      loadBook,
      upsertUser,
      syncUsers,
      getFriends,
      getFollowing,
      getFollowers,
      isFriend,
      isFollowing,
      toggleFriend,
      acceptFriendRequest,
      rejectFriendRequest,
      hasSentFriendRequest,
      hasReceivedFriendRequest,
      toggleFollow,
      refreshCatalog,
      refreshCart,
      refreshOrders,
      refreshSellerData,
      refreshAdminData,
      refreshPosts,
      refreshExchanges,
      getCart,
      addToCart,
      updateCartQty,
      removeCartItem,
      setCartQty,
      removeFromCart,
      clearCart,
      placeOrder,
      cancelOrder,
      completeOrder,
      updateOrderStatus,
      addPost,
      toggleLike,
      addComment,
      setPostHidden,
      deletePost,
      addReport,
      resolveReport,
      setUserStatus,
      updateUserRole,
      deleteUser,
      registerUser,
      saveSellerBook,
      upsertBook,
      deleteSellerBook,
      updateSellerOrderStatus,
      setBookStatus,
      deleteBook,
      addExchange,
      sendExchangeOffer,
      respondExchangeOffer,
      setExchangeStatus,
      deleteExchange,
      findOrCreateConversation,
      createGroupConversation,
      sendMessage,
      refreshConversations,
      markConversationRead,
      unreadCount,
      getProgress,
      saveProgress,
      pushNotification,
      markNotificationsRead,
      daily,
      getDaily,
      earnPoints,
      trackDaily,
      claimTask,
      touchStreak,
      feedPet,
      growPet,
      renamePet,
      redeemReward,
      redemptions,
      matchBlindBox,
      addBlindBox,
      revealBlindBox,
    }),
    [
      users,
      books,
      posts,
      refreshPosts,
      exchanges,
      account.orders,
      reports,
      conversations,
      notifications,
      catalog.shops,
      catalog.categories,
      catalog.vouchers,
      catalog.status,
      account.loaded,
      account.sellerBooks,
      account.sellerOrders,
      account.adminOrders,
      account.myExchanges,
      account.sentOffers,
      userById,
      bookById,
      shopById,
      loadBook,
      upsertUser,
      syncUsers,
      getFriends,
      getFollowing,
      getFollowers,
      isFriend,
      isFollowing,
      toggleFriend,
      acceptFriendRequest,
      rejectFriendRequest,
      hasSentFriendRequest,
      hasReceivedFriendRequest,
      toggleFollow,
      refreshCatalog,
      refreshCart,
      refreshOrders,
      refreshSellerData,
      refreshAdminData,
      refreshPosts,
      refreshExchanges,
      getCart,
      addToCart,
      updateCartQty,
      removeCartItem,
      setCartQty,
      removeFromCart,
      clearCart,
      placeOrder,
      cancelOrder,
      completeOrder,
      updateOrderStatus,
      addPost,
      toggleLike,
      addComment,
      setPostHidden,
      deletePost,
      addReport,
      resolveReport,
      setUserStatus,
      updateUserRole,
      deleteUser,
      registerUser,
      saveSellerBook,
      upsertBook,
      deleteSellerBook,
      updateSellerOrderStatus,
      setBookStatus,
      deleteBook,
      addExchange,
      sendExchangeOffer,
      respondExchangeOffer,
      setExchangeStatus,
      deleteExchange,
      findOrCreateConversation,
      createGroupConversation,
      sendMessage,
      refreshConversations,
      markConversationRead,
      unreadCount,
      getProgress,
      saveProgress,
      pushNotification,
      markNotificationsRead,
      daily,
      getDaily,
      earnPoints,
      trackDaily,
      claimTask,
      touchStreak,
      feedPet,
      growPet,
      renamePet,
      redeemReward,
      redemptions,
      matchBlindBox,
      addBlindBox,
      revealBlindBox,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}