import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { BookOpen, Calendar, Clock, Flame, Package, ShoppingBag, Pencil, Save, X, KeyRound } from 'lucide-react';
import { useApp, useAuth, useToast } from '../hooks/useStore';
import { currency, dateOnly, duration, timeAgo } from '../lib/format';
import { ProgressBar, StatCard } from '../components/common/ui';
import { apiCall, uploadAvatar } from '../services/api';
import { avatarSrc } from '../lib/avatar';

export default function ProfilePage() {
  const { userId } = useParams();
  const { user: authUser, updateProfile, loading } = useAuth();
  const { users, orders, posts, getProgress, books } = useApp();
  const toast = useToast();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ email: '', fullName: '', bio: '', avatarUrl: '' });
  const [passwordForm, setPasswordForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [changingPassword, setChangingPassword] = useState(false);
  const [avatarFile, setAvatarFile] = useState(null);
  const [avatarPreview, setAvatarPreview] = useState('');
  const [uploadingAvatar, setUploadingAvatar] = useState(false);

  const isOwnProfile = !userId || String(userId) === String(authUser?.id ?? '');
  const profileUser = useMemo(() => {
    if (isOwnProfile) return authUser;
    return users.find((u) => String(u.id) === String(userId)) || null;
  }, [isOwnProfile, authUser, userId, users]);

  useEffect(() => {
    const currentUserId = profileUser?.id;
    if (!currentUserId) return;
    apiCall(`/users/${currentUserId}/profile`)
      .then((profile) => setForm({
        email: profile.email || '',
        fullName: profile.fullName || '',
        bio: profile.bio || '',
        avatarUrl: profile.avatarUrl || '',
      }))
      .catch(() => {
        setForm({
          email: profileUser.email || '',
          fullName: profileUser.name || '',
          bio: profileUser.bio || '',
          avatarUrl: profileUser.avatar || '',
        });
      });
  }, [profileUser]);

  if (!profileUser) {
    return (
      <div className="main-layout" style={{ maxWidth: 720 }}>
        <div className="card empty">
          <h3>Không tìm thấy hồ sơ người dùng</h3>
          <p className="small muted">Trang cá nhân này không tồn tại hoặc đã bị xóa.</p>
        </div>
      </div>
    );
  }

  const myOrders = useMemo(() => orders.filter((o) => o.userId === profileUser.id), [orders, profileUser.id]);
  const myPosts = useMemo(() => posts.filter((p) => p.authorId === profileUser.id && !p.hidden), [posts, profileUser.id]);
  const progress = getProgress(profileUser.id);

  const entries = Object.values(progress)
    .map((p) => ({ ...p, book: books.find((b) => b.id === p.bookId) }))
    .filter((p) => p.book)
    .sort((a, b) => b.lastReadAt - a.lastReadAt);

  const spent = myOrders.filter((o) => o.status !== 'cancelled').reduce((s, o) => s + o.total, 0);
  const readSeconds = entries.reduce((s, e) => s + (e.secondsRead || 0), 0);

  const submitPassword = async (e) => {
    e.preventDefault();
    if (passwordForm.newPassword.length < 6) {
      toast('Mật khẩu mới phải có ít nhất 6 ký tự.', 'error');
      return;
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast('Mật khẩu xác nhận không khớp.', 'error');
      return;
    }
    setChangingPassword(true);
    try {
      await apiCall(`/users/${authUser.id}/password`, 'PUT', {
        currentPassword: passwordForm.currentPassword,
        newPassword: passwordForm.newPassword,
      }, { userId: authUser.id });
      setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
      toast('Đổi mật khẩu thành công.', 'success');
    } catch (error) {
      toast(error.message || 'Không thể đổi mật khẩu.', 'error');
    } finally {
      setChangingPassword(false);
    }
  };

  const submitProfile = async (e) => {
    e.preventDefault();
    let avatarUrl = form.avatarUrl;
    if (avatarFile) {
      setUploadingAvatar(true);
      try {
        const uploaded = await uploadAvatar(avatarFile, authUser.id);
        avatarUrl = uploaded.avatarUrl;
      } catch (error) {
        setUploadingAvatar(false);
        return toast(error.message || 'Không thể tải ảnh đại diện lên.', 'error');
      }
      setUploadingAvatar(false);
    }
    const result = await updateProfile({ ...form, avatarUrl });
    if (!result.ok) return toast(result.error, 'error');
    setAvatarFile(null);
    setAvatarPreview('');
    setEditing(false);
    toast('Đã cập nhật thông tin cá nhân.');
  };

  const handleAvatarFile = (event) => {
    const file = event.target.files?.[0] || null;
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(file.type)) {
      event.target.value = '';
      toast('Chỉ chấp nhận ảnh JPG, PNG, WEBP hoặc GIF.', 'error');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      event.target.value = '';
      toast('Ảnh đại diện không được vượt quá 5 MB.', 'error');
      return;
    }
    setAvatarFile(file);
    setAvatarPreview(URL.createObjectURL(file));
  };

  return (
    <div className="main-layout" style={{ maxWidth: 1000 }}>
      <div className="card" style={{ marginBottom: 20 }}>
        <div className="row" style={{ gap: 18, flexWrap: 'wrap' }}>
          <img src={avatarPreview || avatarSrc(profileUser.avatar)} alt="Ảnh đại diện" className="avatar" style={{ width: 86, height: 86, objectFit: 'cover', background: '#fff' }} />
          <div style={{ flex: 1, minWidth: 220 }}>
            <h1 style={{ margin: '0 0 4px', fontSize: 23 }}>{profileUser.name}</h1>
            <p className="small muted" style={{ margin: '0 0 8px' }}>{profileUser.email || 'Thành viên Bookigma'}</p>
            {profileUser.bio && <p className="small" style={{ margin: '0 0 10px' }}>{profileUser.bio}</p>}
            <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
              <span className="badge badge-green">{profileUser.badge || 'Thành viên'}</span>
              <span className="badge row" style={{ gap: 5 }}><Flame size={13} /> {(profileUser.points || 0).toLocaleString('vi-VN')} điểm</span>
              <span className="badge row" style={{ gap: 5 }}><Calendar size={13} /> Tham gia {dateOnly(new Date(profileUser.joinedAt || Date.now()).getTime())}</span>
            </div>
          </div>
          {isOwnProfile ? (
            <div className="row" style={{ gap: 8 }}>
              <button className="btn btn-ghost btn-sm" onClick={() => setEditing((v) => !v)}>
                {editing ? <X size={15} /> : <Pencil size={15} />} {editing ? 'Đóng' : 'Chỉnh sửa'}
              </button>
              <Link to="/orders" className="btn btn-ghost btn-sm"><Package size={15} /> Đơn hàng</Link>
              <Link to="/library" className="btn btn-primary btn-sm"><BookOpen size={15} /> Tủ sách</Link>
            </div>
          ) : (
            <Link to={`/chat`} className="btn btn-primary btn-sm">Nhắn tin</Link>
          )}
        </div>

        {editing && (
          <div>
            <form onSubmit={submitProfile} className="card" style={{ marginTop: 20, background: 'var(--bg-soft)' }}>
            <h3 style={{ marginTop: 0 }}>Chỉnh sửa thông tin cá nhân</h3>
            <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))' }}>
              <div className="field">
                <label className="label">Họ và tên</label>
                <input className="input" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
              </div>
              <div className="field">
                <label className="label">Email</label>
                <input className="input" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
              </div>
              <div className="field">
                <label className="label">Ảnh đại diện</label>
                <input className="input" type="file" accept="image/png,image/jpeg,image/webp,image/gif" onChange={handleAvatarFile} />
                <p className="tiny muted" style={{ margin: '5px 0 0' }}>Chọn ảnh từ máy tính (JPG, PNG, WEBP hoặc GIF; tối đa 5 MB). Không nhập link ảnh.</p>
                {avatarFile && <button type="button" className="btn btn-ghost btn-sm" style={{ marginTop: 6 }} onClick={() => { setAvatarFile(null); setAvatarPreview(''); }}>Hủy chọn ảnh</button>}
              </div>
            </div>
            <div className="field" style={{ marginTop: 12 }}>
              <label className="label">Giới thiệu</label>
              <textarea className="textarea" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} rows={4} />
            </div>
            <button className="btn btn-primary" type="submit" disabled={loading || uploadingAvatar} style={{ marginTop: 12 }}>
              <Save size={15} /> {loading || uploadingAvatar ? 'Đang lưu...' : 'Lưu thay đổi'}
            </button>
            </form>

          {isOwnProfile && (
            <form onSubmit={submitPassword} className="card" style={{ marginTop: 16, background: 'var(--bg-soft)' }}>
              <h3 style={{ marginTop: 0 }}><KeyRound size={17} style={{ verticalAlign: 'middle', marginRight: 6 }} />Đổi mật khẩu</h3>
              <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
                <div className="field"><label className="label">Mật khẩu hiện tại</label><input className="input" type="password" value={passwordForm.currentPassword} onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })} required /></div>
                <div className="field"><label className="label">Mật khẩu mới</label><input className="input" type="password" minLength={6} value={passwordForm.newPassword} onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })} required /></div>
                <div className="field"><label className="label">Xác nhận mật khẩu mới</label><input className="input" type="password" minLength={6} value={passwordForm.confirmPassword} onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })} required /></div>
              </div>
              <button className="btn btn-primary" type="submit" disabled={changingPassword} style={{ marginTop: 12 }}><KeyRound size={15} /> {changingPassword ? 'Đang đổi...' : 'Đổi mật khẩu'}</button>
            </form>
          )}
          </div>
        )}
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', marginBottom: 20 }}>
        <StatCard icon={BookOpen} label="Sách trong tủ" value={entries.length} sub={`${entries.filter((e) => e.finished).length} cuốn đã xong`} />
        <StatCard icon={Clock} label="Thời gian đọc" value={duration(readSeconds)} color="var(--purple)" bg="var(--purple-soft)" />
        <StatCard icon={ShoppingBag} label="Đã chi tiêu" value={currency(spent)} sub={`${myOrders.length} đơn hàng`} color="var(--info)" bg="var(--info-soft)" />
        <StatCard icon={Flame} label="Bài viết" value={myPosts.length} sub={`${myPosts.reduce((s, p) => s + (p.likeCount ?? p.likedBy?.length ?? 0), 0)} lượt thích`} color="var(--warning)" bg="var(--warning-soft)" />
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))' }}>
        <div className="card">
          <h3 style={{ margin: '0 0 14px', fontSize: 16 }}>Đang đọc gần đây</h3>
          {entries.length === 0 && <p className="small muted">Chưa có cuốn nào trong tủ sách.</p>}
          {entries.slice(0, 5).map((e) => (
            <Link key={e.bookId} to={`/read/${e.bookId}`} className="row" style={{ padding: '10px 0', borderBottom: '1px solid var(--border-color)', gap: 12, alignItems: 'flex-start' }}>
              <img src={e.book.cover} alt="" className="book-cover" style={{ width: 40, height: 55 }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="small strong truncate">{e.book.title}</div>
                <div className="tiny muted" style={{ margin: '3px 0 6px' }}>{e.percent}% · {timeAgo(e.lastReadAt)}</div>
                <ProgressBar percent={e.percent} height={4} />
              </div>
            </Link>
          ))}
        </div>

        <div className="card">
          <h3 style={{ margin: '0 0 14px', fontSize: 16 }}>Bài viết của tôi</h3>
          {myPosts.length === 0 && <p className="small muted">Bạn chưa đăng bài viết nào.</p>}
          {myPosts.slice(0, 5).map((p) => (
            <div key={p.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--border-color)' }}>
              <p className="small clamp-2" style={{ margin: '0 0 6px' }}>{p.content}</p>
              <div className="row tiny muted" style={{ gap: 14 }}>
                <span>{timeAgo(p.time)}</span>
                <span>{p.likeCount ?? p.likedBy?.length ?? 0} thích</span>
                <span>{p.comments?.length || 0} bình luận</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
